using System;
using System.Collections.Generic;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager Instance;

    Dictionary<int, InventoryItem> m_dicInventoryItem = new Dictionary<int, InventoryItem>();

    public event Action<InventoryItem> OnAddItem;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void AddItem(int _id)
    {
        if (m_dicInventoryItem.ContainsKey(_id))
            ++m_dicInventoryItem[_id].stock;
        else
            m_dicInventoryItem.Add(_id, new InventoryItem() { productid = _id, stock = 1 });

        OnAddItem?.Invoke(m_dicInventoryItem[_id]);
    }

    public bool TryUseItem(int _id)
    {
        if (m_dicInventoryItem.ContainsKey(_id))
        {
            if (m_dicInventoryItem[_id].stock <= 0)
            {
                // �κ��丮 ����� ������
                return false;
            }
            else
            {
                --m_dicInventoryItem[_id].stock;
                // ������
                return true;
            }
        }
        else
            //��ü�� �Ȱ����� ����
            return false;
    }

    public int GetStock(int _id)
    {
        if (m_dicInventoryItem.ContainsKey(_id))
            return m_dicInventoryItem[_id].stock;
        else
            return 0;
    }

    public List<InventoryItem> GetAllInventoryItems()
    {
        List<InventoryItem> m_listItems = new List<InventoryItem>();

        foreach (InventoryItem item in m_dicInventoryItem.Values)
        {
            if (item.stock > 0)
                m_listItems.Add(item);
        }

        return m_listItems;
    }

}

